package Controller;

import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXButton;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

public class AcceuilVehiculesController implements Initializable {
	  @FXML
	    private AnchorPane AcceuilVehicules;

	    @FXML
	    private JFXButton gestionVehicule;

	    @FXML
	    private JFXButton activitevehicule;

	    @FXML
	    void ActiviteVehicules(ActionEvent event) {

	    }

	    @FXML
	    void gestionvehicule(ActionEvent event) {

	    }
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

}
